The form was divided into multiple parts.
I took two parts, One was the applicant information page in which only merge fiels were added and the form was not iterative. The second one was coverage section in which the field was intended to appear only whwn it is applicable. So, I created multiple subforms for the same.
Please check what I am missing and what I need to remember always while creating forms.

I had a doubt in checkbox that how should I map it. By square brackets, by merge fileds or by conditional logic (X) logic. ?